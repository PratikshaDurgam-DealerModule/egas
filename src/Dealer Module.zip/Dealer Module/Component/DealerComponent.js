import React from 'react'
import 'bootstrap/dist/css/bootstrap.css'
import '../Css/LoginStyle.css'
import DealerLogin from './DealerLogin'
//import '../StaffModule/Component/regstyle.css'
function DealerComponent() {
  
    return (
      
        <div>
         <DealerLogin/>
        </div>
        
    )
}

export default DealerComponent